package com.example.hp.myapplication.Common;

import com.example.hp.myapplication.Model.User;

public class Common {
    public static User currentUser;
}
